import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import DashboardPage from '@/pages/DashboardPage';
import EvaluationPage from '@/pages/EvaluationPage';
import ChecklistPage from '@/pages/ChecklistPage';
import ReportsPage from '@/pages/ReportsPage';
import type { PageId } from '@/types';

const pageMeta: Record<PageId, { title: string; subtitle: string }> = {
  dashboard: { title: 'داشبورد QC', subtitle: 'نمای کلی وضعیت ارزیابی‌ها' },
  evaluation: { title: 'ارزیابی تماس', subtitle: 'بررسی و تحلیل مکالمات تماس' },
  checklist: { title: 'چک‌لیست QC', subtitle: 'معیارهای ارزیابی کیفیت تماس' },
  reports: { title: 'گزارش‌ها', subtitle: 'گزارش‌های ارزیابی QC' },
};

export default function App() {
  const [page, setPage] = useState<PageId>('dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);

  const meta = pageMeta[page];

  return (
    <div className="flex h-screen bg-ink-50 overflow-hidden">
      <Sidebar
        active={page}
        onNavigate={setPage}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header
          title={meta.title}
          subtitle={meta.subtitle}
          onOpenMobile={() => setMobileOpen(true)}
        />
        <main className="flex-1 overflow-y-auto px-4 sm:px-6 lg:px-8 py-6">
          {page === 'dashboard' && <DashboardPage />}
          {page === 'evaluation' && <EvaluationPage />}
          {page === 'checklist' && <ChecklistPage />}
          {page === 'reports' && <ReportsPage />}
        </main>
      </div>
    </div>
  );
}
