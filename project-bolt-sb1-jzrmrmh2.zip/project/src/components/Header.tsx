import { Menu, Bell, Search } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle: string;
  onOpenMobile: () => void;
}

export default function Header({ title, subtitle, onOpenMobile }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-ink-100">
      <div className="flex items-center justify-between px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobile}
            className="lg:hidden p-2 rounded-lg text-ink-600 hover:bg-ink-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-ink-900">{title}</h2>
            <p className="text-ink-400 text-xs sm:text-sm hidden sm:block">{subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-ink-50 border border-ink-100 w-64">
            <Search className="w-4 h-4 text-ink-400" />
            <input
              type="text"
              placeholder="جستجو..."
              className="bg-transparent text-sm outline-none flex-1 placeholder:text-ink-400"
            />
          </div>
          <button className="relative p-2.5 rounded-xl bg-ink-50 text-ink-600 hover:bg-ink-100 transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 left-2 w-2 h-2 rounded-full bg-gold-400 ring-2 ring-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
