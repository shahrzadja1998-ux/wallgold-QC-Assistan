import {
  LayoutDashboard,
  ClipboardCheck,
  ListChecks,
  FileBarChart,
  ShieldCheck,
  type LucideIcon,
} from 'lucide-react';
import type { PageId } from '@/types';

interface NavItem {
  id: PageId;
  label: string;
  icon: LucideIcon;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'داشبورد QC', icon: LayoutDashboard },
  { id: 'evaluation', label: 'ارزیابی تماس', icon: ClipboardCheck },
  { id: 'checklist', label: 'چک‌لیست QC', icon: ListChecks },
  { id: 'reports', label: 'گزارش‌ها', icon: FileBarChart },
];

interface SidebarProps {
  active: PageId;
  onNavigate: (page: PageId) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export default function Sidebar({ active, onNavigate, mobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-ink-950/40 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed lg:static inset-y-0 right-0 z-50 w-72 bg-ink-950 flex flex-col transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-6 border-b border-ink-800">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-gold-glow">
            <ShieldCheck className="w-6 h-6 text-ink-950" strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-white font-bold text-base leading-tight">WallGold</h1>
            <p className="text-gold-400 text-xs font-medium">QC Assistant</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-4 py-6 space-y-1.5">
          <p className="text-ink-500 text-xs font-semibold px-3 mb-3">منوی اصلی</p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = active === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-l from-gold-500/20 to-gold-400/10 text-gold-300 border border-gold-500/30'
                    : 'text-ink-300 hover:bg-ink-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" strokeWidth={isActive ? 2.5 : 2} />
                <span>{item.label}</span>
                {isActive && (
                  <span className="mr-auto w-1.5 h-1.5 rounded-full bg-gold-400 animate-scale-in" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-4 py-4 border-t border-ink-800">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-ink-900">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center text-ink-950 font-bold text-sm">
              ر
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">رها کریمی</p>
              <p className="text-ink-400 text-xs truncate">کارشناس QC</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
