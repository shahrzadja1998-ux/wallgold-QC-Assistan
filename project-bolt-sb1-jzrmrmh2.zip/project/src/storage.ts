import type { SavedEvaluation } from '@/types';

const STORAGE_KEY = 'wallgold_qc_evaluations';

export function loadEvaluations(): SavedEvaluation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed as SavedEvaluation[];
  } catch {
    return [];
  }
}

export function saveEvaluation(ev: SavedEvaluation): void {
  const all = loadEvaluations();
  all.unshift(ev);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function generateId(): string {
  return `EV-${Date.now().toString(36).toUpperCase()}`;
}

export function computeWeightedScore(
  scores: { criterionId: number; score: number }[],
  criteria: { id: number; weight: number }[]
): number {
  const totalWeight = criteria.reduce((sum, c) => sum + c.weight, 0);
  if (totalWeight === 0) return 0;
  let weightedSum = 0;
  for (const c of criteria) {
    const s = scores.find((sc) => sc.criterionId === c.id);
    const score = s ? s.score : 0;
    weightedSum += (score / 100) * c.weight;
  }
  return Math.round((weightedSum / totalWeight) * 100);
}

export function countCriticalErrors(
  scores: { criterionId: number; status: string }[]
): number {
  return scores.filter((s) => s.status === 'failed').length;
}

export function determineStatus(score: number, criticalErrors: number): 'passed' | 'needs-review' | 'failed' {
  if (criticalErrors >= 3 || score < 60) return 'failed';
  if (score >= 85 && criticalErrors === 0) return 'passed';
  return 'needs-review';
}
