import { useState } from 'react';
import { Save, RotateCcw, CheckCircle2 } from 'lucide-react';
import { checklistItems } from '@/data';
import type { ChecklistResult } from '@/types';

export default function ChecklistPage() {
  const [results, setResults] = useState<ChecklistResult[]>(() =>
    checklistItems.map((item) => ({ itemId: item.id, score: 0, note: '' }))
  );

  const updateScore = (itemId: number, score: number) => {
    setResults((prev) =>
      prev.map((r) => (r.itemId === itemId ? { ...r, score } : r))
    );
  };

  const updateNote = (itemId: number, note: string) => {
    setResults((prev) =>
      prev.map((r) => (r.itemId === itemId ? { ...r, note } : r))
    );
  };

  const totalMax = checklistItems.reduce((sum, i) => sum + i.maxScore, 0);
  const totalScore = results.reduce((sum, r) => sum + r.score, 0);
  const scorePct = Math.round((totalScore / totalMax) * 100);

  const completedCount = results.filter((r) => r.score > 0).length;

  const handleReset = () => {
    setResults(checklistItems.map((item) => ({ itemId: item.id, score: 0, note: '' })));
  };

  return (
    <div className="space-y-6">
      {/* Summary bar */}
      <div className="card p-6 animate-fade-in">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-ink-900 mb-1">چک‌لیست ارزیابی QC</h3>
            <p className="text-ink-400 text-sm">
              {completedCount.toLocaleString('fa-IR')} از {checklistItems.length.toLocaleString('fa-IR')} معیار ارزیابی شده
            </p>
          </div>
          <div className="flex items-center gap-4">
            {/* Progress ring */}
            <div className="relative w-16 h-16">
              <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="28" fill="none" stroke="#ECEEF0" strokeWidth="5" />
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  fill="none"
                  stroke="#C99A3E"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray={`${(scorePct / 100) * 176} 176`}
                  className="transition-all duration-500"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-sm font-bold text-ink-900 tabular-nums">
                  {scorePct.toLocaleString('fa-IR')}٪
                </span>
              </div>
            </div>
            <div>
              <p className="text-ink-400 text-xs">امتیاز کلی</p>
              <p className="text-xl font-bold text-ink-900 tabular-nums">
                {totalScore.toLocaleString('fa-IR')} / {totalMax.toLocaleString('fa-IR')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Checklist table */}
      <div className="card overflow-hidden animate-fade-in">
        {/* Desktop table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/50">
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500 w-12">#</th>
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500">معیار ارزیابی</th>
                <th className="text-center px-4 py-3.5 text-xs font-semibold text-ink-500 w-28">بارم</th>
                <th className="text-center px-4 py-3.5 text-xs font-semibold text-ink-500 w-40">امتیاز (از حداکثر)</th>
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500 w-56">توضیحات</th>
              </tr>
            </thead>
            <tbody>
              {checklistItems.map((item, idx) => {
                const result = results.find((r) => r.itemId === item.id)!;
                return (
                  <tr
                    key={item.id}
                    className="border-b border-ink-50 last:border-0 hover:bg-ink-50/40 transition-colors"
                  >
                    <td className="px-4 py-3.5 text-sm text-ink-400 tabular-nums">
                      {(idx + 1).toLocaleString('fa-IR')}
                    </td>
                    <td className="px-4 py-3.5">
                      <p className="text-sm font-medium text-ink-900">{item.criterion}</p>
                      <p className="text-xs text-ink-400 mt-0.5">{item.description}</p>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="badge bg-ink-100 text-ink-600 tabular-nums">
                        {item.weight.toLocaleString('fa-IR')}٪
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2 justify-center">
                        <input
                          type="range"
                          min={0}
                          max={item.maxScore}
                          value={result.score}
                          onChange={(e) => updateScore(item.id, Number(e.target.value))}
                          className="w-24 accent-gold-500 cursor-pointer"
                        />
                        <span className="text-sm font-semibold text-ink-700 tabular-nums min-w-[3rem] text-center">
                          {result.score.toLocaleString('fa-IR')} / {item.maxScore.toLocaleString('fa-IR')}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <input
                        type="text"
                        value={result.note}
                        onChange={(e) => updateNote(item.id, e.target.value)}
                        placeholder="توضیح..."
                        className="w-full px-3 py-1.5 rounded-lg border border-ink-100 bg-ink-50 text-xs text-ink-700 focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="lg:hidden divide-y divide-ink-50">
          {checklistItems.map((item, idx) => {
            const result = results.find((r) => r.itemId === item.id)!;
            return (
              <div key={item.id} className="p-4">
                <div className="flex items-start gap-2 mb-3">
                  <span className="text-xs text-ink-400 tabular-nums mt-0.5">
                    {(idx + 1).toLocaleString('fa-IR')}
                  </span>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-ink-900">{item.criterion}</p>
                    <p className="text-xs text-ink-400 mt-0.5">{item.description}</p>
                  </div>
                  <span className="badge bg-ink-100 text-ink-600 tabular-nums flex-shrink-0">
                    {item.weight.toLocaleString('fa-IR')}٪
                  </span>
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <input
                    type="range"
                    min={0}
                    max={item.maxScore}
                    value={result.score}
                    onChange={(e) => updateScore(item.id, Number(e.target.value))}
                    className="flex-1 accent-gold-500 cursor-pointer"
                  />
                  <span className="text-sm font-semibold text-ink-700 tabular-nums min-w-[3.5rem] text-center">
                    {result.score.toLocaleString('fa-IR')} / {item.maxScore.toLocaleString('fa-IR')}
                  </span>
                </div>
                <input
                  type="text"
                  value={result.note}
                  onChange={(e) => updateNote(item.id, e.target.value)}
                  placeholder="توضیح..."
                  className="w-full px-3 py-2 rounded-lg border border-ink-100 bg-ink-50 text-xs text-ink-700 focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3">
        <button onClick={handleReset} className="btn-ghost">
          <RotateCcw className="w-4 h-4" />
          بازنشانی
        </button>
        <button className="btn-primary">
          <Save className="w-4 h-4" />
          ذخیره ارزیابی
        </button>
      </div>

      {completedCount === checklistItems.length && (
        <div className="card p-4 flex items-center gap-3 animate-scale-in border border-emerald-200 bg-emerald-50/50">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <p className="text-sm text-emerald-700">
            تمام معیارها ارزیابی شد. امتیاز کلی: {totalScore.toLocaleString('fa-IR')} از {totalMax.toLocaleString('fa-IR')}
          </p>
        </div>
      )}
    </div>
  );
}
