import { useState, useMemo } from 'react';
import { Download, Filter, CheckCircle2, Eye, XCircle, Star } from 'lucide-react';
import { reportData } from '@/data';
import { loadEvaluations } from '@/storage';
import type { ReportItem } from '@/types';

const statusConfig: Record<
  ReportItem['status'],
  { label: string; badge: string; icon: typeof CheckCircle2 }
> = {
  passed: { label: 'موفق', badge: 'bg-emerald-50 text-emerald-600', icon: CheckCircle2 },
  'needs-review': { label: 'نیازمند بررسی', badge: 'bg-gold-50 text-gold-600', icon: Eye },
  failed: { label: 'ناموفق', badge: 'bg-red-50 text-red-600', icon: XCircle },
};

export default function ReportsPage() {
  const [filter, setFilter] = useState<'all' | ReportItem['status']>('all');

  const allReports = useMemo<ReportItem[]>(() => {
    const saved = loadEvaluations().map((ev, idx) => ({
      id: 10000 + idx,
      agent: ev.agent,
      callId: ev.callId,
      date: ev.callDate,
      subject: ev.subject,
      totalScore: ev.totalScore,
      criticalErrors: ev.criticalErrors,
      status: ev.status,
    }));
    return [...saved, ...reportData];
  }, []);

  const filtered = filter === 'all' ? allReports : allReports.filter((r) => r.status === filter);

  const counts = {
    all: allReports.length,
    passed: allReports.filter((r) => r.status === 'passed').length,
    'needs-review': allReports.filter((r) => r.status === 'needs-review').length,
    failed: allReports.filter((r) => r.status === 'failed').length,
  };

  const filterButtons: { id: typeof filter; label: string; count: number }[] = [
    { id: 'all', label: 'همه', count: counts.all },
    { id: 'passed', label: 'موفق', count: counts.passed },
    { id: 'needs-review', label: 'نیازمند بررسی', count: counts['needs-review'] },
    { id: 'failed', label: 'ناموفق', count: counts.failed },
  ];

  return (
    <div className="space-y-6">
      {/* Filter bar */}
      <div className="card p-4 animate-fade-in">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="w-4 h-4 text-ink-400 ml-1" />
            {filterButtons.map((btn) => (
              <button
                key={btn.id}
                onClick={() => setFilter(btn.id)}
                className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                  filter === btn.id
                    ? 'bg-ink-900 text-white'
                    : 'bg-ink-50 text-ink-600 hover:bg-ink-100'
                }`}
              >
                {btn.label}
                <span className="mr-1.5 text-xs opacity-70 tabular-nums">
                  {btn.count.toLocaleString('fa-IR')}
                </span>
              </button>
            ))}
          </div>
          <button className="btn-ghost">
            <Download className="w-4 h-4" />
            خروجی
          </button>
        </div>
      </div>

      {/* Reports table */}
      <div className="card overflow-hidden animate-fade-in">
        {/* Desktop table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/50">
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500">شناسه تماس</th>
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500">کارشناس</th>
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500">تاریخ</th>
                <th className="text-right px-4 py-3.5 text-xs font-semibold text-ink-500">موضوع</th>
                <th className="text-center px-4 py-3.5 text-xs font-semibold text-ink-500">امتیاز</th>
                <th className="text-center px-4 py-3.5 text-xs font-semibold text-ink-500">خطای بحرانی</th>
                <th className="text-center px-4 py-3.5 text-xs font-semibold text-ink-500">وضعیت</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r, idx) => {
                const cfg = statusConfig[r.status];
                const StatusIcon = cfg.icon;
                const scoreColor =
                  r.totalScore >= 85
                    ? 'text-emerald-600'
                    : r.totalScore >= 70
                    ? 'text-gold-600'
                    : 'text-red-600';
                const isSaved = idx < counts.all - reportData.length;
                return (
                  <tr
                    key={r.id}
                    className="border-b border-ink-50 last:border-0 hover:bg-ink-50/40 transition-colors"
                  >
                    <td className="px-4 py-3.5 text-sm font-medium text-ink-700 tabular-nums">
                      <div className="flex items-center gap-2">
                        {isSaved && <Star className="w-3.5 h-3.5 text-gold-400 fill-gold-400" />}
                        {r.callId}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-sm text-ink-900">{r.agent}</td>
                    <td className="px-4 py-3.5 text-sm text-ink-500 tabular-nums">{r.date}</td>
                    <td className="px-4 py-3.5 text-sm text-ink-600">{r.subject}</td>
                    <td className="px-4 py-3.5 text-center">
                      <span className={`text-sm font-bold tabular-nums ${scoreColor}`}>
                        {r.totalScore.toLocaleString('fa-IR')}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className={`text-sm font-semibold tabular-nums ${r.criticalErrors > 0 ? 'text-red-600' : 'text-ink-400'}`}>
                        {r.criticalErrors.toLocaleString('fa-IR')}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className={`badge ${cfg.badge}`}>
                        <StatusIcon className="w-3.5 h-3.5" />
                        {cfg.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="lg:hidden divide-y divide-ink-50">
          {filtered.map((r, idx) => {
            const cfg = statusConfig[r.status];
            const StatusIcon = cfg.icon;
            const scoreColor =
              r.totalScore >= 85
                ? 'text-emerald-600'
                : r.totalScore >= 70
                ? 'text-gold-600'
                : 'text-red-600';
            const isSaved = idx < counts.all - reportData.length;
            return (
              <div key={r.id} className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      {isSaved && <Star className="w-3.5 h-3.5 text-gold-400 fill-gold-400" />}
                      <p className="text-sm font-medium text-ink-900">{r.agent}</p>
                    </div>
                    <p className="text-xs text-ink-400 tabular-nums mt-0.5">
                      {r.callId} • {r.date}
                    </p>
                  </div>
                  <span className={`badge ${cfg.badge}`}>
                    <StatusIcon className="w-3.5 h-3.5" />
                    {cfg.label}
                  </span>
                </div>
                <p className="text-sm text-ink-600 mb-2">{r.subject}</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-ink-400">امتیاز:</span>
                    <span className={`text-sm font-bold tabular-nums ${scoreColor}`}>
                      {r.totalScore.toLocaleString('fa-IR')}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-ink-400">خطای بحرانی:</span>
                    <span className={`text-sm font-semibold tabular-nums ${r.criticalErrors > 0 ? 'text-red-600' : 'text-ink-400'}`}>
                      {r.criticalErrors.toLocaleString('fa-IR')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="p-12 text-center text-ink-400 text-sm">
            گزارشی برای این فیلتر یافت نشد
          </div>
        )}
      </div>
    </div>
  );
}
