import { useState, useMemo } from 'react';
import {
  User,
  Hash,
  Calendar,
  Tag,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  TrendingUp,
  Award,
  Target,
  GraduationCap,
  Save,
  RotateCcw,
  ClipboardList,
} from 'lucide-react';
import { sampleConversation, evaluationCriteria } from '@/data';
import type { CriterionStatus, CriterionScore, SavedEvaluation } from '@/types';
import {
  computeWeightedScore,
  countCriticalErrors,
  determineStatus,
  generateId,
  saveEvaluation,
} from '@/storage';

const MIN_CONVERSATION_LENGTH = 50;

const statusConfig: Record<
  CriterionStatus,
  { label: string; badge: string; icon: typeof CheckCircle2; dot: string }
> = {
  passed: { label: 'رعایت شد', badge: 'bg-emerald-50 text-emerald-600', icon: CheckCircle2, dot: 'bg-emerald-400' },
  'needs-improvement': { label: 'نیازمند بهبود', badge: 'bg-gold-50 text-gold-600', icon: TrendingUp, dot: 'bg-gold-400' },
  failed: { label: 'رعایت نشد', badge: 'bg-red-50 text-red-600', icon: XCircle, dot: 'bg-red-400' },
};

const statusOrder: CriterionStatus[] = ['passed', 'needs-improvement', 'failed'];

function defaultScores(): CriterionScore[] {
  return evaluationCriteria.map((c) => ({
    criterionId: c.id,
    score: 0,
    status: 'needs-improvement' as CriterionStatus,
    note: '',
  }));
}

export default function EvaluationPage() {
  const [agent, setAgent] = useState('');
  const [callId, setCallId] = useState('');
  const [callDate, setCallDate] = useState('');
  const [subject, setSubject] = useState('');
  const [conversation, setConversation] = useState(sampleConversation);
  const [scores, setScores] = useState<CriterionScore[]>(defaultScores);
  const [qcSummary, setQcSummary] = useState('');
  const [trainingAction, setTrainingAction] = useState('');
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const totalWeight = useMemo(
    () => evaluationCriteria.reduce((sum, c) => sum + c.weight, 0),
    []
  );

  const finalScore = useMemo(
    () => computeWeightedScore(scores, evaluationCriteria),
    [scores]
  );

  const criticalErrors = useMemo(
    () => countCriticalErrors(scores),
    [scores]
  );

  const overallStatus = useMemo(
    () => determineStatus(finalScore, criticalErrors),
    [finalScore, criticalErrors]
  );

  const scoreColor =
    finalScore >= 85
      ? 'text-emerald-600'
      : finalScore >= 70
      ? 'text-gold-600'
      : 'text-red-600';

  const updateScore = (criterionId: number, score: number) => {
    setScores((prev) =>
      prev.map((s) =>
        s.criterionId === criterionId ? { ...s, score: Math.max(0, Math.min(100, score)) } : s
      )
    );
  };

  const updateStatus = (criterionId: number, status: CriterionStatus) => {
    setScores((prev) =>
      prev.map((s) => (s.criterionId === criterionId ? { ...s, status } : s))
    );
  };

  const updateNote = (criterionId: number, note: string) => {
    setScores((prev) =>
      prev.map((s) => (s.criterionId === criterionId ? { ...s, note } : s))
    );
  };

  const handleReset = () => {
    setScores(defaultScores());
    setQcSummary('');
    setTrainingAction('');
    setError('');
    setSubmitted(false);
  };

  const handleSubmit = () => {
    setError('');

    const trimmed = conversation.trim();
    if (trimmed.length === 0) {
      setError('متن مکالمه خالی است. لطفاً متن مکالمه را وارد کنید.');
      return;
    }
    if (trimmed.length < MIN_CONVERSATION_LENGTH) {
      setError(
        `متن مکالمه خیلی کوتاه است (${trimmed.length.toLocaleString('fa-IR')} کاراکتر). لطفاً متن کامل‌تری از مکالمه وارد کنید.`
      );
      return;
    }

    const evaluation: SavedEvaluation = {
      id: generateId(),
      agent: agent || 'نامشخص',
      callId: callId || 'نامشخص',
      callDate: callDate || 'نامشخص',
      subject: subject || 'نامشخص',
      conversation,
      scores,
      totalScore: finalScore,
      criticalErrors,
      status: overallStatus,
      qcSummary,
      trainingAction,
      createdAt: new Date().toISOString(),
    };

    saveEvaluation(evaluation);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-16 animate-scale-in">
        <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center mb-5">
          <CheckCircle2 className="w-10 h-10 text-emerald-500" />
        </div>
        <h3 className="text-xl font-bold text-ink-900 mb-2">ارزیابی با موفقیت ثبت شد</h3>
        <p className="text-ink-400 text-sm mb-1">
          امتیاز نهایی: <span className={`font-bold tabular-nums ${scoreColor}`}>{finalScore.toLocaleString('fa-IR')}</span> از ۱۰۰
        </p>
        <p className="text-ink-400 text-sm mb-6">
          این ارزیابی در بخش «گزارش‌ها» قابل مشاهده است و در آمار داشبورد لحاظ شده است.
        </p>
        <button onClick={handleReset} className="btn-gold">
          <Sparkles className="w-4 h-4" />
          ارزیابی جدید
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="animate-fade-in">
        <div className="flex items-center gap-3 mb-1">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-gold-glow">
            <ClipboardList className="w-5 h-5 text-ink-950" strokeWidth={2.5} />
          </div>
          <h2 className="text-xl font-bold text-ink-900">ارزیابی تماس</h2>
        </div>
        <p className="text-ink-400 text-sm pr-13">
          اطلاعات تماس را وارد کنید، مکالمه را بررسی کنید و برای هر معیار امتیاز و وضعیت تعیین کنید.
        </p>
      </div>

      {/* Form fields */}
      <div className="card p-6 animate-fade-in">
        <h3 className="font-bold text-ink-900 mb-5">اطلاعات تماس</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-2">نام کارشناس</label>
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={agent}
                onChange={(e) => setAgent(e.target.value)}
                placeholder="مثلاً: مریم احمدی"
                className="input-field pr-10"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-2">شناسه تماس</label>
            <div className="relative">
              <Hash className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={callId}
                onChange={(e) => setCallId(e.target.value)}
                placeholder="مثلاً: CL-۲۴۰۱-۰۰۹"
                className="input-field pr-10"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-2">تاریخ تماس</label>
            <div className="relative">
              <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={callDate}
                onChange={(e) => setCallDate(e.target.value)}
                placeholder="مثلاً: ۱۴۰۳/۰۷/۰۵"
                className="input-field pr-10"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-600 mb-2">موضوع تماس</label>
            <div className="relative">
              <Tag className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-400" />
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="مثلاً: استعلام موجودی"
                className="input-field pr-10"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Conversation */}
      <div className="card p-6 animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-ink-900">متن مکالمه</h3>
          <span className="text-ink-400 text-sm tabular-nums">
            {conversation.length.toLocaleString('fa-IR')} کاراکتر
          </span>
        </div>
        <textarea
          value={conversation}
          onChange={(e) => setConversation(e.target.value)}
          rows={10}
          className="w-full px-4 py-3 rounded-xl border border-ink-200 bg-ink-50 text-sm text-ink-800 leading-7 resize-none focus:outline-none focus:border-gold-400 focus:bg-white focus:ring-2 focus:ring-gold-200 transition-all"
          placeholder="متن مکالمه مشتری و کارشناس را اینجا وارد کنید..."
        />
      </div>

      {/* Error message */}
      {error && (
        <div className="card p-4 flex items-start gap-3 animate-scale-in border border-red-200 bg-red-50/50">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-700 mb-0.5">خطا</p>
            <p className="text-sm text-red-600 leading-6">{error}</p>
          </div>
        </div>
      )}

      {/* Final Score Card */}
      <div className="card p-6 border border-gold-200 bg-gradient-to-bl from-gold-50/40 to-white animate-fade-in">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-gold-glow">
              <Award className="w-7 h-7 text-ink-950" strokeWidth={2} />
            </div>
            <div>
              <h3 className="font-bold text-ink-900 text-lg">امتیاز نهایی QC</h3>
              <p className="text-ink-400 text-sm">محاسبه لحظه‌ای بر اساس میانگین وزنی معیارها</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {/* Progress ring */}
            <div className="relative w-16 h-16">
              <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="28" fill="none" stroke="#ECEEF0" strokeWidth="5" />
                <circle
                  cx="32"
                  cy="32"
                  r="28"
                  fill="none"
                  stroke={finalScore >= 85 ? '#3B9B6E' : finalScore >= 70 ? '#C99A3E' : '#D64545'}
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray={`${(finalScore / 100) * 176} 176`}
                  className="transition-all duration-500"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-sm font-bold text-ink-900 tabular-nums">
                  {finalScore.toLocaleString('fa-IR')}٪
                </span>
              </div>
            </div>
            <div>
              <span className={`text-4xl font-bold tabular-nums ${scoreColor}`}>
                {finalScore.toLocaleString('fa-IR')}
              </span>
              <span className="text-ink-400 text-lg mr-1">/ ۱۰۰</span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-ink-400">خطای بحرانی:</span>
                <span className={`text-sm font-semibold tabular-nums ${criticalErrors > 0 ? 'text-red-600' : 'text-ink-400'}`}>
                  {criticalErrors.toLocaleString('fa-IR')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scoring Table */}
      <div className="card overflow-hidden animate-fade-in">
        <div className="flex items-center gap-2 px-6 py-4 border-b border-ink-100">
          <div className="w-8 h-8 rounded-lg bg-ink-100 flex items-center justify-center">
            <Target className="w-4.5 h-4.5 text-ink-700" />
          </div>
          <h3 className="font-bold text-ink-900">امتیازدهی معیارهای QC</h3>
          <span className="text-ink-400 text-sm mr-auto">مجموع وزن‌ها: {totalWeight.toLocaleString('fa-IR')}</span>
        </div>

        {/* Desktop table */}
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-ink-100 bg-ink-50/50">
                <th className="text-right px-4 py-3 text-xs font-semibold text-ink-500 w-10">#</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-ink-500">نام معیار</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-ink-500 w-20">وزن</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-ink-500 w-56">امتیاز (۰ تا ۱۰۰)</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-ink-500 w-44">وضعیت</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-ink-500 w-48">توضیح QC</th>
              </tr>
            </thead>
            <tbody>
              {evaluationCriteria.map((c, idx) => {
                const s = scores.find((sc) => sc.criterionId === c.id)!;
                return (
                  <tr
                    key={c.id}
                    className="border-b border-ink-50 last:border-0 hover:bg-ink-50/40 transition-colors"
                  >
                    <td className="px-4 py-3 text-sm text-ink-400 tabular-nums">
                      {(idx + 1).toLocaleString('fa-IR')}
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{c.name}</td>
                    <td className="px-4 py-3 text-center">
                      <span className="badge bg-ink-100 text-ink-600 tabular-nums">
                        {c.weight.toLocaleString('fa-IR')}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5 justify-center">
                        <input
                          type="range"
                          min={0}
                          max={100}
                          value={s.score}
                          onChange={(e) => updateScore(c.id, Number(e.target.value))}
                          className="w-28 accent-gold-500 cursor-pointer"
                        />
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={s.score}
                          onChange={(e) => updateScore(c.id, Number(e.target.value))}
                          className="w-14 px-2 py-1 rounded-lg border border-ink-100 bg-ink-50 text-sm text-center font-semibold text-ink-700 tabular-nums focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                        />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-center">
                        {statusOrder.map((st) => {
                          const cfg = statusConfig[st];
                          const Icon = cfg.icon;
                          const isActive = s.status === st;
                          return (
                            <button
                              key={st}
                              onClick={() => updateStatus(c.id, st)}
                              title={cfg.label}
                              className={`p-1.5 rounded-lg transition-all ${
                                isActive
                                  ? `${cfg.badge} ring-1 ring-current`
                                  : 'text-ink-300 hover:bg-ink-50'
                              }`}
                            >
                              <Icon className="w-4 h-4" />
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <input
                        type="text"
                        value={s.note}
                        onChange={(e) => updateNote(c.id, e.target.value)}
                        placeholder="توضیح..."
                        className="w-full px-3 py-1.5 rounded-lg border border-ink-100 bg-ink-50 text-xs text-ink-700 focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="lg:hidden divide-y divide-ink-50">
          {evaluationCriteria.map((c, idx) => {
            const s = scores.find((sc) => sc.criterionId === c.id)!;
            return (
              <div key={c.id} className="p-4">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-start gap-2">
                    <span className="text-xs text-ink-400 tabular-nums mt-0.5">
                      {(idx + 1).toLocaleString('fa-IR')}
                    </span>
                    <p className="text-sm font-medium text-ink-900">{c.name}</p>
                  </div>
                  <span className="badge bg-ink-100 text-ink-600 tabular-nums flex-shrink-0">
                    {c.weight.toLocaleString('fa-IR')}
                  </span>
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={s.score}
                    onChange={(e) => updateScore(c.id, Number(e.target.value))}
                    className="flex-1 accent-gold-500 cursor-pointer"
                  />
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={s.score}
                    onChange={(e) => updateScore(c.id, Number(e.target.value))}
                    className="w-16 px-2 py-1 rounded-lg border border-ink-100 bg-ink-50 text-sm text-center font-semibold text-ink-700 tabular-nums focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                  />
                </div>
                <div className="flex items-center gap-1 mb-3">
                  {statusOrder.map((st) => {
                    const cfg = statusConfig[st];
                    const Icon = cfg.icon;
                    const isActive = s.status === st;
                    return (
                      <button
                        key={st}
                        onClick={() => updateStatus(c.id, st)}
                        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                          isActive ? cfg.badge : 'text-ink-300 bg-ink-50'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {cfg.label}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="text"
                  value={s.note}
                  onChange={(e) => updateNote(c.id, e.target.value)}
                  placeholder="توضیح QC..."
                  className="w-full px-3 py-2 rounded-lg border border-ink-100 bg-ink-50 text-xs text-ink-700 focus:outline-none focus:border-gold-400 focus:bg-white transition-all"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* QC Summary & Training Action */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-ink-100 flex items-center justify-center">
              <ClipboardList className="w-4.5 h-4.5 text-ink-700" />
            </div>
            <h4 className="font-bold text-ink-900">جمع‌بندی QC</h4>
          </div>
          <textarea
            value={qcSummary}
            onChange={(e) => setQcSummary(e.target.value)}
            rows={4}
            className="w-full px-4 py-3 rounded-xl border border-ink-200 bg-ink-50 text-sm text-ink-800 leading-7 resize-none focus:outline-none focus:border-gold-400 focus:bg-white focus:ring-2 focus:ring-gold-200 transition-all"
            placeholder="نظر کارشناس QC درباره این تماس را ثبت کنید..."
          />
        </div>

        <div className="card p-5 animate-fade-in">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-gold-50 flex items-center justify-center">
              <GraduationCap className="w-4.5 h-4.5 text-gold-600" />
            </div>
            <h4 className="font-bold text-ink-900">اقدام اصلاحی / آموزشی</h4>
          </div>
          <textarea
            value={trainingAction}
            onChange={(e) => setTrainingAction(e.target.value)}
            rows={4}
            className="w-full px-4 py-3 rounded-xl border border-ink-200 bg-ink-50 text-sm text-ink-800 leading-7 resize-none focus:outline-none focus:border-gold-400 focus:bg-white focus:ring-2 focus:ring-gold-200 transition-all"
            placeholder="پیشنهاد آموزشی یا اقدام اصلاحی را ثبت کنید..."
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-center gap-3 pb-4">
        <button onClick={handleReset} className="btn-ghost">
          <RotateCcw className="w-4 h-4" />
          بازنشانی
        </button>
        <button onClick={handleSubmit} className="btn-gold px-8 py-3 text-base">
          <Save className="w-5 h-5" />
          ثبت ارزیابی QC
        </button>
      </div>
    </div>
  );
}
