import { useState, useMemo, useEffect } from 'react';
import {
  Headphones,
  TrendingUp,
  AlertTriangle,
  Eye,
  ArrowUp,
  ArrowDown,
  type LucideIcon,
} from 'lucide-react';
import { dashboardStats, callStatusData, scoreTrendData, reportData } from '@/data';
import { loadEvaluations } from '@/storage';
import type { StatCard, CallStatus } from '@/types';

const iconMap: Record<string, LucideIcon> = {
  Headphones,
  TrendingUp,
  AlertTriangle,
  Eye,
};

const accentStyles: Record<StatCard['accent'], { bg: string; text: string; ring: string }> = {
  gold: { bg: 'bg-gold-50', text: 'text-gold-600', ring: 'ring-gold-200' },
  ink: { bg: 'bg-ink-100', text: 'text-ink-700', ring: 'ring-ink-200' },
  success: { bg: 'bg-emerald-50', text: 'text-emerald-600', ring: 'ring-emerald-200' },
  error: { bg: 'bg-red-50', text: 'text-red-600', ring: 'ring-red-200' },
};

function StatCardItem({ stat }: { stat: StatCard }) {
  const Icon = iconMap[stat.icon];
  const accent = accentStyles[stat.accent];

  return (
    <div className="stat-card animate-fade-in">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl ${accent.bg} ${accent.text} flex items-center justify-center ring-1 ${accent.ring}`}>
          <Icon className="w-6 h-6" strokeWidth={2} />
        </div>
        {stat.trend && (
          <span
            className={`badge ${stat.trend.positive ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}
          >
            {stat.trend.positive ? (
              <ArrowUp className="w-3 h-3" />
            ) : (
              <ArrowDown className="w-3 h-3" />
            )}
            {stat.trend.value}
          </span>
        )}
      </div>
      <p className="text-ink-400 text-sm mb-1">{stat.label}</p>
      <div className="flex items-baseline gap-1.5">
        <span className="text-3xl font-bold text-ink-900 tabular-nums">{stat.value}</span>
        {stat.unit && <span className="text-ink-400 text-sm">{stat.unit}</span>}
      </div>
      <div className="absolute bottom-0 right-0 left-0 h-1 bg-gradient-to-l from-transparent via-gold-300/40 to-transparent" />
    </div>
  );
}

function StatusChart({ data }: { data: CallStatus[] }) {
  const total = data.reduce((sum, s) => sum + s.count, 0);
  let cumulative = 0;
  const segments = data.map((s) => {
    const pct = total > 0 ? (s.count / total) * 100 : 0;
    const start = cumulative;
    cumulative += pct;
    return { ...s, pct, start };
  });

  return (
    <div className="card p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-bold text-ink-900">وضعیت تماس‌ها</h3>
        <span className="text-ink-400 text-sm">مجموع: {total.toLocaleString('fa-IR')}</span>
      </div>

      <div className="flex h-3 rounded-full overflow-hidden mb-5">
        {segments.map((s, i) => (
          <div
            key={i}
            className="h-full transition-all duration-500 hover:opacity-80"
            style={{ width: `${s.pct}%`, backgroundColor: s.color }}
          />
        ))}
      </div>

      <div className="space-y-3">
        {data.map((s, i) => (
          <div key={i} className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }} />
              <span className="text-sm text-ink-600">{s.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-ink-900 tabular-nums">
                {s.count.toLocaleString('fa-IR')}
              </span>
              <span className="text-xs text-ink-400 tabular-nums">
                ({total > 0 ? Math.round((s.count / total) * 100).toLocaleString('fa-IR') : '۰'}٪)
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScoreTrendChart({ extraScores }: { extraScores: number[] }) {
  const maxScore = 100;
  const chartHeight = 200;
  const allData = [...scoreTrendData];
  const extraStart = allData.length;

  for (let i = 0; i < extraScores.length && i < 7; i++) {
    allData.push({ day: `+${(i + 1).toLocaleString('fa-IR')}`, score: extraScores[i] });
  }

  return (
    <div className="card p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-5">
        <h3 className="font-bold text-ink-900">روند امتیازها</h3>
        <span className="badge bg-gold-50 text-gold-600">۷ روز اخیر</span>
      </div>

      <div className="relative" style={{ height: chartHeight }}>
        {[0, 25, 50, 75, 100].map((g) => (
          <div
            key={g}
            className="absolute right-0 left-0 border-t border-ink-100"
            style={{ bottom: `${g}%` }}
          >
            <span className="absolute -top-2.5 right-0 text-[10px] text-ink-300 tabular-nums">
              {g.toLocaleString('fa-IR')}
            </span>
          </div>
        ))}

        <div className="absolute inset-0 flex items-end justify-between gap-2 pr-6">
          {allData.slice(-7).map((d, i) => {
            const heightPct = (d.score / maxScore) * 100;
            const isHighest = d.score === Math.max(...allData.slice(-7).map((s) => s.score));
            const isExtra = i >= extraStart - (allData.length - 7);
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                <div className="relative w-full flex flex-col justify-end" style={{ height: '100%' }}>
                  <div
                    className={`w-full rounded-t-lg transition-all duration-500 origin-bottom animate-grow-bar ${
                      isHighest
                        ? 'bg-gradient-to-t from-gold-500 to-gold-300'
                        : isExtra
                        ? 'bg-gradient-to-t from-gold-400 to-gold-200'
                        : 'bg-gradient-to-t from-ink-300 to-ink-200 group-hover:from-gold-400 group-hover:to-gold-300'
                    }`}
                    style={{ height: `${heightPct}%` }}
                  >
                    <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-semibold text-ink-700 tabular-nums opacity-0 group-hover:opacity-100 transition-opacity">
                      {d.score.toLocaleString('fa-IR')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex justify-between gap-2 mt-3 pr-6">
        {allData.slice(-7).map((d, i) => (
          <span key={i} className="flex-1 text-center text-xs text-ink-400">
            {d.day}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [savedCount, setSavedCount] = useState(0);
  const [savedAvg, setSavedAvg] = useState(0);
  const [savedCritical, setSavedCritical] = useState(0);
  const [savedNeedsReview, setSavedNeedsReview] = useState(0);
  const [savedStatusData, setSavedStatusData] = useState<CallStatus[]>(callStatusData);
  const [savedScores, setSavedScores] = useState<number[]>([]);

  useEffect(() => {
    const evals = loadEvaluations();
    setSavedCount(evals.length);
    if (evals.length > 0) {
      setSavedAvg(Math.round(evals.reduce((s, e) => s + e.totalScore, 0) / evals.length));
      setSavedCritical(evals.reduce((s, e) => s + e.criticalErrors, 0));
      setSavedNeedsReview(evals.filter((e) => e.status === 'needs-review' || e.status === 'failed').length);
      setSavedScores(evals.map((e) => e.totalScore));

      const passed = evals.filter((e) => e.status === 'passed').length + reportData.filter((r) => r.status === 'passed').length;
      const needsReview = evals.filter((e) => e.status === 'needs-review').length + reportData.filter((r) => r.status === 'needs-review').length;
      const failed = evals.filter((e) => e.status === 'failed').length + reportData.filter((r) => r.status === 'failed').length;
      setSavedStatusData([
        { label: 'موفق', count: passed, color: '#3B9B6E' },
        { label: 'نیازمند بررسی', count: needsReview, color: '#C99A3E' },
        { label: 'ناموفق', count: failed, color: '#D64545' },
      ]);
    } else {
      setSavedStatusData(callStatusData);
    }
  }, []);

  const liveStats = useMemo<StatCard[]>(() => {
    const baseReviewed = 1248 + savedCount;
    const baseAvg = savedCount > 0 ? Math.round((84.6 * 1248 + savedAvg * savedCount) / (1248 + savedCount)) : 84.6;
    const baseCritical = 23 + savedCritical;
    const baseNeedsReview = 47 + savedNeedsReview;

    return dashboardStats.map((stat) => {
      if (stat.id === 'reviewed') return { ...stat, value: baseReviewed.toLocaleString('fa-IR') };
      if (stat.id === 'avg-score') return { ...stat, value: baseAvg.toLocaleString('fa-IR', { maximumFractionDigits: 1 }) };
      if (stat.id === 'critical') return { ...stat, value: baseCritical.toLocaleString('fa-IR') };
      if (stat.id === 'needs-review') return { ...stat, value: baseNeedsReview.toLocaleString('fa-IR') };
      return stat;
    });
  }, [savedCount, savedAvg, savedCritical, savedNeedsReview]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {liveStats.map((stat) => (
          <StatCardItem key={stat.id} stat={stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <StatusChart data={savedStatusData} />
        <ScoreTrendChart extraScores={savedScores} />
      </div>
    </div>
  );
}
