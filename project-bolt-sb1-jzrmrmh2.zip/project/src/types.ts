export type PageId = 'dashboard' | 'evaluation' | 'checklist' | 'reports';

export interface StatCard {
  id: string;
  label: string;
  value: string;
  unit?: string;
  icon: string;
  trend?: { value: string; positive: boolean };
  accent: 'gold' | 'ink' | 'success' | 'error';
}

export interface CallStatus {
  label: string;
  count: number;
  color: string;
}

export interface ScoreTrend {
  day: string;
  score: number;
}

export interface ChecklistItem {
  id: number;
  criterion: string;
  description: string;
  maxScore: number;
  weight: number;
}

export interface ChecklistResult {
  itemId: number;
  score: number;
  note: string;
}

export interface ReportItem {
  id: number;
  agent: string;
  callId: string;
  date: string;
  subject: string;
  totalScore: number;
  criticalErrors: number;
  status: 'passed' | 'needs-review' | 'failed';
}

export type CriterionStatus = 'passed' | 'needs-improvement' | 'failed';

export interface QCCriterionResult {
  criterion: string;
  status: CriterionStatus;
  note: string;
}

export interface AnalysisResult {
  totalScore: number;
  strengths: string[];
  improvements: string[];
  criticalErrors: string[];
  criteria: QCCriterionResult[];
  trainingSuggestion: string;
}

export interface EvaluationCriterion {
  id: number;
  name: string;
  weight: number;
}

export interface CriterionScore {
  criterionId: number;
  score: number;
  status: CriterionStatus;
  note: string;
}

export interface SavedEvaluation {
  id: string;
  agent: string;
  callId: string;
  callDate: string;
  subject: string;
  conversation: string;
  scores: CriterionScore[];
  totalScore: number;
  criticalErrors: number;
  status: 'passed' | 'needs-review' | 'failed';
  qcSummary: string;
  trainingAction: string;
  createdAt: string;
}
