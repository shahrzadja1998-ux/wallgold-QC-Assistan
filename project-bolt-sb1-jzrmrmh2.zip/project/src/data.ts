import type {
  StatCard,
  CallStatus,
  ScoreTrend,
  ChecklistItem,
  ReportItem,
  AnalysisResult,
  EvaluationCriterion,
} from '@/types';

export const dashboardStats: StatCard[] = [
  {
    id: 'reviewed',
    label: 'تماس‌های بررسی‌شده',
    value: '۱٬۲۴۸',
    icon: 'Headphones',
    trend: { value: '٪۱۲ افزایش', positive: true },
    accent: 'ink',
  },
  {
    id: 'avg-score',
    label: 'میانگین امتیاز QC',
    value: '۸۴٫۶',
    unit: 'از ۱۰۰',
    icon: 'TrendingUp',
    trend: { value: '٪۳ افزایش', positive: true },
    accent: 'gold',
  },
  {
    id: 'critical',
    label: 'خطاهای بحرانی',
    value: '۲۳',
    icon: 'AlertTriangle',
    trend: { value: '٪۸ کاهش', positive: true },
    accent: 'error',
  },
  {
    id: 'needs-review',
    label: 'نیازمند بررسی',
    value: '۴۷',
    icon: 'Eye',
    trend: { value: '٪۵ افزایش', positive: false },
    accent: 'success',
  },
];

export const callStatusData: CallStatus[] = [
  { label: 'موفق', count: 892, color: '#3B9B6E' },
  { label: 'نیازمند بررسی', count: 248, color: '#C99A3E' },
  { label: 'ناموفق', count: 108, color: '#D64545' },
];

export const scoreTrendData: ScoreTrend[] = [
  { day: 'شنبه', score: 78 },
  { day: 'یکشنبه', score: 82 },
  { day: 'دوشنبه', score: 80 },
  { day: 'سه‌شنبه', score: 85 },
  { day: 'چهارشنبه', score: 87 },
  { day: 'پنجشنبه', score: 86 },
  { day: 'جمعه', score: 89 },
];

export const checklistItems: ChecklistItem[] = [
  {
    id: 1,
    criterion: 'شروع استاندارد مکالمه',
    description: 'آغاز تماس با سلام و احوال‌پرسی مناسب و اعلام نام سازمان',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 2,
    criterion: 'معرفی کارشناس',
    description: 'معرفی کامل نام و surname کارشناس به مشتری',
    maxScore: 5,
    weight: 5,
  },
  {
    id: 3,
    criterion: 'احراز هویت',
    description: 'احراز هویت دقیق و طبق پروتکل‌های امنیتی سازمان',
    maxScore: 10,
    weight: 15,
  },
  {
    id: 4,
    criterion: 'کشف نیاز مشتری',
    description: 'پرسش‌های مناسب برای شناسایی دقیق نیاز مشتری',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 5,
    criterion: 'صحت اطلاعات',
    description: 'ارائه اطلاعات صحیح و به‌روز به مشتری',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 6,
    criterion: 'لحن و ادبیات',
    description: 'استفاده از لحن محترمانه و ادبیات حرفه‌ای',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 7,
    criterion: 'گوش دادن فعال',
    description: 'گوش دادن دقیق و عدم قطع کلام مشتری',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 8,
    criterion: 'مدیریت اعتراض',
    description: 'برخورد مناسب با اعتراضات و دغدغه‌های مشتری',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 9,
    criterion: 'ارائه راهکار',
    description: 'ارائه راهکار مناسب و عملیاتی برای مشتری',
    maxScore: 10,
    weight: 10,
  },
  {
    id: 10,
    criterion: 'جمع‌بندی',
    description: 'جمع‌بندی مکالمه و اطمینان از رضایت مشتری',
    maxScore: 10,
    weight: 5,
  },
  {
    id: 11,
    criterion: 'پایان استاندارد مکالمه',
    description: 'پایان مکالمه با تشکر و خداحافظی مناسب',
    maxScore: 5,
    weight: 5,
  },
];

export const reportData: ReportItem[] = [
  {
    id: 1,
    agent: 'مریم احمدی',
    callId: 'CL-۲۴۰۱-۰۰۱',
    date: '۱۴۰۳/۰۷/۰۱',
    subject: 'استعلام موجودی حساب',
    totalScore: 92,
    criticalErrors: 0,
    status: 'passed',
  },
  {
    id: 2,
    agent: 'علی رضایی',
    callId: 'CL-۲۴۰۱-۰۰۲',
    date: '۱۴۰۳/۰۷/۰۱',
    subject: 'گزارش تراکنش ناموفق',
    totalScore: 68,
    criticalErrors: 2,
    status: 'failed',
  },
  {
    id: 3,
    agent: 'سحر کریمی',
    callId: 'CL-۲۴۰۱-۰۰۳',
    date: '۱۴۰۳/۰۷/۰۲',
    subject: 'درخواست کارت بانکی',
    totalScore: 78,
    criticalErrors: 1,
    status: 'needs-review',
  },
  {
    id: 4,
    agent: 'حسین موسوی',
    callId: 'CL-۲۴۰۱-۰۰۴',
    date: '۱۴۰۳/۰۷/۰۲',
    subject: 'مشکل ورود به اپلیکیشن',
    totalScore: 88,
    criticalErrors: 0,
    status: 'passed',
  },
  {
    id: 5,
    agent: 'نگار صادقی',
    callId: 'CL-۲۴۰۱-۰۰۵',
    date: '۱۴۰۳/۰۷/۰۳',
    subject: 'استعلام وام',
    totalScore: 95,
    criticalErrors: 0,
    status: 'passed',
  },
  {
    id: 6,
    agent: 'رضا قاسمی',
    callId: 'CL-۲۴۰۱-۰۰۶',
    date: '۱۴۰۳/۰۷/۰۳',
    subject: 'تغییر شماره تماس',
    totalScore: 72,
    criticalErrors: 1,
    status: 'needs-review',
  },
  {
    id: 7,
    agent: 'زهرا نوری',
    callId: 'CL-۲۴۰۱-۰۰۷',
    date: '۱۴۰۳/۰۷/۰۴',
    subject: 'شکایت از خدمات',
    totalScore: 64,
    criticalErrors: 3,
    status: 'failed',
  },
  {
    id: 8,
    agent: 'محمد جعفری',
    callId: 'CL-۲۴۰۱-۰۰۸',
    date: '۱۴۰۳/۰۷/۰۴',
    subject: 'راهنمایی افتتاح حساب',
    totalScore: 90,
    criticalErrors: 0,
    status: 'passed',
  },
];

export const sampleAnalysisResult: AnalysisResult = {
  totalScore: 87,
  strengths: [
    'شروع و پایان مکالمه کاملاً طبق استاندارد سازمان انجام شده است.',
    'احراز هویت مشتری به‌درستی و با رعایت پروتکل‌های امنیتی اجرا شده است.',
    'لحن کارشناس در طول تماس محترمانه و حرفه‌ای بوده است.',
    'ارائه راهکار برای مشتری واضح و عملیاتی بوده است.',
  ],
  improvements: [
    'کشف نیاز مشتری می‌توانید کامل‌تر باشد؛ پرسش‌های باز بیشتر استفاده شود.',
    'در بخش مدیریت اعتراض، کارشناس می‌توانید همدلی بیشتری نشان دهد.',
    'گوش دادن فعال: در یک مورد کلام مشتری قطع شده است.',
  ],
  criticalErrors: [
    'عدم تأیید مجدد اطلاعات حساس قبل از قطع تماس.',
  ],
  criteria: [
    { criterion: 'شروع استاندارد مکالمه', status: 'passed', note: 'سلام و احوال‌پرسی مناسب و اعلام نام سازمان انجام شده است.' },
    { criterion: 'معرفی کارشناس', status: 'passed', note: 'نام کارشناس به‌درستی معرفی شده است.' },
    { criterion: 'همدلی', status: 'needs-improvement', note: 'همدلی در بخش اعتراض مشتری کافی نبوده است.' },
    { criterion: 'کشف نیاز مشتری', status: 'needs-improvement', note: 'پرسش‌های باز کافی برای کشف دقیق نیاز استفاده نشده است.' },
    { criterion: 'صحت پاسخگویی', status: 'passed', note: 'اطلاعات ارائه‌شده صحیح و به‌روز بوده است.' },
    { criterion: 'لحن و ادبیات', status: 'passed', note: 'لحن محترمانه و ادبیات حرفه‌ای رعایت شده است.' },
    { criterion: 'گوش دادن فعال', status: 'needs-improvement', note: 'در یک مورد کلام مشتری پیش از اتمام قطع شده است.' },
    { criterion: 'مدیریت اعتراض', status: 'needs-improvement', note: 'بهبود در پذیرش و مدیریت دغدغه‌های مشتری توصیه می‌شود.' },
    { criterion: 'ارائه راهکار', status: 'passed', note: 'راهکار واضح و عملیاتی ارائه شده است.' },
    { criterion: 'جمع‌بندی', status: 'passed', note: 'جمع‌بندی مکالمه انجام و رضایت مشتری تأیید شده است.' },
    { criterion: 'پایان استاندارد مکالمه', status: 'passed', note: 'تشکر و خداحافظی مناسب انجام شده است.' },
  ],
  trainingSuggestion:
    'شرکت در دوره «گوش دادن فعال و مدیریت اعتراض» به مدت ۸ ساعت توصیه می‌شود. همچنین تمرین پرسش‌های باز برای کشف بهتر نیاز مشتری در جلسات کوچینگ هفتگی پیشنهاد می‌گردد.',
};

export const evaluationCriteria: EvaluationCriterion[] = [
  { id: 1, name: 'رعایت سناریو ابتدایی', weight: 4 },
  { id: 2, name: 'عدم تأخیر در شروع مکالمه', weight: 3 },
  { id: 3, name: 'لحن و انرژی شروع مکالمه', weight: 3 },
  { id: 4, name: 'رعایت آداب و اصول اخلاقی مکالمه', weight: 4 },
  { id: 5, name: 'ارتباط مؤثر', weight: 4 },
  { id: 6, name: 'فن بیان در مکالمه', weight: 4 },
  { id: 7, name: 'عدم استفاده از جملات و کلمات محاوره‌ای و ممنوعه', weight: 4 },
  { id: 8, name: 'همدلی و درک شرایط', weight: 4 },
  { id: 9, name: 'لحن و انرژی وسط مکالمه', weight: 3 },
  { id: 10, name: 'کیفیت صدا و صدای محیط', weight: 3 },
  { id: 11, name: 'تصدیق مناسب صحبت', weight: 3 },
  { id: 12, name: 'رعایت استاندارد هولد', weight: 3 },
  { id: 13, name: 'مدیریت مکالمه', weight: 4 },
  { id: 14, name: 'توجه و تمرکز در مکالمه', weight: 4 },
  { id: 15, name: 'عدم قطع کلام کاربر', weight: 4 },
  { id: 16, name: 'پرسش سؤالات کلیدی', weight: 4 },
  { id: 17, name: 'پاسخگویی صحیح', weight: 4 },
  { id: 18, name: 'انتخاب موضوع صحیح', weight: 3 },
  { id: 19, name: 'ثبت اطلاعات کامل تیکت', weight: 4 },
  { id: 20, name: 'گردشکار صحیح', weight: 4 },
  { id: 21, name: 'پاسخ فراتر از انتظار', weight: 3 },
  { id: 22, name: 'نتیجه‌گیری و جمع‌بندی', weight: 4 },
  { id: 23, name: 'عدم تعجیل در پایان دادن مکالمه', weight: 3 },
  { id: 24, name: 'سایر نیازها و سناریو نظرسنجی', weight: 3 },
  { id: 25, name: 'لحن و انرژی پایان مکالمه', weight: 3 },
  { id: 26, name: 'پایان استاندارد مکالمه', weight: 4 },
];

export const sampleConversation = `کارشناس: سلام، مرکز تماس والگلد، با مریم احمدی صحبت می‌کنم. چطور می‌توانم کمکتون کنم؟

مشتری: سلام، خسته نباشید. می‌خواستم موجودی حسابم رو استعلام بگیرم.

کارشناس: حتماً. برای احراز هویت، ممنون می‌شم کد ملیتون رو اعلام بفرمایید.

مشتری: بفرمایید، کد ملی بنده ۰۰۱2345678 هست.

کارشناس: ممنون از شما. لطفاً کمی صبر کنید تا اطلاعات رو بررسی کنم... بله، موجودی حساب شما یک میلیون و دویست هزار تومان هست.

مشتری: ممنون. یه سوال دیگه هم داشتم، می‌شه آخرین تراکنش‌هام رو هم بگید؟

کارشناس: البته. آخرین تراکنش شما خرید با کارت به مبلغ ۵۰ هزار تومان در تاریخ ۱۴۰۳/۰۶/۳۱ بوده. آیا سوال دیگه‌ای هم دارید؟

مشتری: نه، ممنون از راهنماییتون.

کارشناس: خواهش می‌کنم. خوشحال می‌شم که تونستم کمکتون کنم. تماس بعدی رو هم منتظرتون هستیم. خدانگهدار.

مشتری: خدانگهدار.`;
