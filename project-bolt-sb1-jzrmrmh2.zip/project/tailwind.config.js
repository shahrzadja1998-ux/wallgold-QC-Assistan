/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Vazirmatn', 'sans-serif'],
      },
      colors: {
        gold: {
          50: '#FBF7EE',
          100: '#F5EBD3',
          200: '#EAD7A8',
          300: '#DDBE74',
          400: '#D4A857',
          500: '#C99A3E',
          600: '#B8842F',
          700: '#976827',
          800: '#7A5322',
          900: '#63461F',
        },
        ink: {
          50: '#F6F7F8',
          100: '#ECEEF0',
          200: '#D5D9DD',
          300: '#B0B7BE',
          400: '#828C95',
          500: '#5F6973',
          600: '#4A525B',
          700: '#3C434A',
          800: '#2A2F35',
          900: '#1A1D21',
          950: '#0D0F12',
        },
      },
      boxShadow: {
        'gold-glow': '0 0 20px rgba(201, 154, 62, 0.15)',
        card: '0 1px 3px rgba(0,0,0,0.04), 0 4px 16px rgba(0,0,0,0.06)',
        'card-hover': '0 2px 8px rgba(0,0,0,0.06), 0 8px 30px rgba(0,0,0,0.08)',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-in': {
          '0%': { opacity: '0', transform: 'translateX(-12px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        'grow-bar': {
          '0%': { transform: 'scaleY(0)' },
          '100%': { transform: 'scaleY(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.4s ease-out',
        'slide-in': 'slide-in 0.3s ease-out',
        'scale-in': 'scale-in 0.25s ease-out',
        'grow-bar': 'grow-bar 0.6s ease-out',
      },
    },
  },
  plugins: [],
};
